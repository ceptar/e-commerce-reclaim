export const APP_META_TITLE = 'Purplleface';
export const APP_META_DESCRIPTION = 'A place for your needs';
export const DEMO_API_URL = 'https://backend.purplleface.com/shop-api';
export const COMPANY_EMAIL = 'purplleface@info.np';
export const DEFAULT_PAGE_SIZE = 100;
